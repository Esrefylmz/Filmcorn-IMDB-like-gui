<?php

include "config.php";

if (isset($_POST['username'])){

$username = $_POST['username'];
$message = $_POST['message'];

echo $username . " " . $message . "<br>";

$sql_statement = "INSERT INTO messages(username,message)
					VALUES ('$username','$message')";

$result = mysqli_query($db, $sql_statement);

header ("Location: index.php");

}

else
{

	echo "The form is not set.";

}


?>