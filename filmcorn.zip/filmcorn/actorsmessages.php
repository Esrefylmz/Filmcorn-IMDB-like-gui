<!DOCTYPE html>
<html>
<head>
	<title>ActorMessages</title>

<style>
table {
  font-family: arial, sans-serif;
  border-collapse: collapse;
  width: 100%;
}

td, th {
  border: 1px solid #dddddd;
  text-align: left;
  padding: 8px;
}

tr:nth-child(even) {
  background-color: #dddddd;
}
</style>

</head>
<body>

<div align="center">

	<table>

<tr> <th> ID </th> <th> Actor </th>  <th>Birth</th>  <th>Death</th> </tr> 

<?php

include "actorsconfig.php";

$sql_statement = "SELECT * FROM actors";


$result = mysqli_query($db, $sql_statement);

while($row = mysqli_fetch_assoc($result))
{
  $id = $row['actorid'];
  $actorname = $row['name'];
  $birth = $row['birth']; 
  $death = $row['death'];

	echo "<tr>" . "<th>" . $id . "</th>" . "<th>" . $actorname . "</th>" .  "<th>" . $birth . "</th>" .  "<th>" . $death . "</th>" . "</tr>";
}

?>

</table>
</div>

</body>
</html>