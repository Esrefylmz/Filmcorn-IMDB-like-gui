<!DOCTYPE html>
<html>
<head>
	<title>DirectMessages</title>

<style>
table {
  font-family: arial, sans-serif;
  border-collapse: collapse;
  width: 100%;
}

td, th {
  border: 1px solid #dddddd;
  text-align: left;
  padding: 8px;
}

tr:nth-child(even) {
  background-color: #dddddd;
}
</style>

</head>
<body>

<div align="center">

	<table>

<tr>  <th> DIRECTOR NAME </th> <th> THE FILM </th>   </tr>

<?php

include "actorsconfig.php";

$sql_statement1 = "SELECT * FROM director d, content c, direct d2 where d.directorid = d2.directorid and d2.id = c.id";

$result = mysqli_query($db, $sql_statement1);

while($row = mysqli_fetch_assoc($result))
{
  $title = $row['title'];
  $name = $row['name'];

	echo "<tr>" . "<th>" . $name  . "</th>" . "<th>" . $title  . "</th>" . "</tr>";
}

?>

</table>
</div>

</body>
</html>